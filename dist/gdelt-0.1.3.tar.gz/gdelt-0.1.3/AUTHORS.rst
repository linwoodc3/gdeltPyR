Full-on open source project with the following contributors:

* Linwood Creekmore
